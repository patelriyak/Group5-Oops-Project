from flask import Blueprint, render_template, request, redirect, url_for
from lib import lib
from flask import jsonify
from datetime import datetime, timedelta
from time import gmtime, strftime, mktime
import re
import mysql.connector
from model.user import User

model_user = User()

conn = mysql.connector.connect(user='root', password='', host='127.0.0.1', database='restaurantmanagement')

caterplace_page = Blueprint("caterplace_page", __name__)

@caterplace_page.route("/caterplace", methods=["GET"])
def cater_place():
	mycursor = conn.cursor()

	xyz = lib.username
	cater_value = mycursor.execute(f"SELECT * FROM catertable where email='{xyz}'" )
	caterDetails = mycursor.fetchall()
	return render_template("caterplaced.html", caterDetails = caterDetails)