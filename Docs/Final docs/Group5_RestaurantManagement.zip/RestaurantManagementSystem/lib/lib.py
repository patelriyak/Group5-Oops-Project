

username = None
current = None